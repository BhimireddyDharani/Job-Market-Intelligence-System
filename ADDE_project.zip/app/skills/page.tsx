'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { skillsDemandData } from '@/lib/mock-data';
import { TrendingUp, Users, Award } from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF7C7C'];

export default function SkillsPage() {
  const sortedByDemand = [...skillsDemandData].sort((a, b) => b.demand - a.demand);
  const sortedByGrowth = [...skillsDemandData].sort((a, b) => b.growth - a.growth);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Skills Demand Analytics
            </h1>
            <p className="text-muted-foreground">
              Understand which skills are in highest demand in the job market
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Top Skill</p>
                <p className="text-2xl font-bold mt-1">{sortedByDemand[0]?.skill}</p>
                <p className="text-xs text-green-600 mt-2">
                  {sortedByDemand[0]?.demand.toLocaleString()} positions
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Award className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Fastest Growing</p>
                <p className="text-2xl font-bold mt-1">{sortedByGrowth[0]?.skill}</p>
                <p className="text-xs text-green-600 mt-2">
                  +{sortedByGrowth[0]?.growth.toFixed(1)}% YoY
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-accent" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Total Positions</p>
                <p className="text-2xl font-bold mt-1">
                  {(skillsDemandData.reduce((sum, s) => sum + s.demand, 0) / 1000).toFixed(1)}K
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  across all skills
                </p>
              </div>
            </Card>
          </div>

          {/* Main Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Demand vs Growth Scatter-like */}
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Demand by Skill</h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={sortedByDemand}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="skill" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="demand" fill="#0088FE" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Growth Rate */}
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Growth Rate by Skill</h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={sortedByGrowth}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="skill" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="growth" fill="#00C49F" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Skills Table */}
          <Card className="p-6">
            <h2 className="text-lg font-bold mb-6">Skills Ranking</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Rank</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Skill</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Demand</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Growth Rate</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Trend</th>
                  </tr>
                </thead>
                <tbody>
                  {skillsDemandData.map((skill, idx) => (
                    <tr key={idx} className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="py-3 px-4 text-muted-foreground font-semibold">#{idx + 1}</td>
                      <td className="py-3 px-4 font-semibold text-foreground">{skill.skill}</td>
                      <td className="py-3 px-4 text-foreground">
                        {skill.demand.toLocaleString()} positions
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-green-600 font-semibold">+{skill.growth.toFixed(1)}%</span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${Math.min(skill.growth * 2, 100)}%` }}
                          />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
