'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
} from 'recharts';
import {
  salaryInsights,
  companySalaryByExperience,
  skillsDemandData,
} from '@/lib/mock-data';
import { DollarSign, TrendingUp, MapPin } from 'lucide-react';

const salaryBySkill = [
  { skill: 'Machine Learning', avgSalary: 2350000 },
  { skill: 'Kubernetes', avgSalary: 2280000 },
  { skill: 'AWS', avgSalary: 2150000 },
  { skill: 'Python', avgSalary: 2050000 },
  { skill: 'Docker', avgSalary: 1980000 },
  { skill: 'React', avgSalary: 1850000 },
  { skill: 'Node.js', avgSalary: 1750000 },
  { skill: 'Java', avgSalary: 1680000 },
];

export default function SalaryPage() {
  const avgAllSalaries = (
    salaryInsights.reduce((sum, loc) => sum + loc.avgSalary, 0) /
    salaryInsights.length
  ).toFixed(0);

  return (
    <div className="flex h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8 max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-10">
            <h1 className="text-5xl font-black bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent mb-3">
              Salary Insights
            </h1>
            <p className="text-lg text-muted-foreground font-medium">
              Real salary data for India's tech industry by location, experience & skills
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                  <DollarSign className="w-7 h-7 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-wide">Avg Salary</p>
                  <p className="text-3xl font-bold mt-2 text-foreground">₹{(avgAllSalaries / 100000).toFixed(1)}L</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    across all major cities
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-secondary/20 to-secondary/5 flex items-center justify-center">
                  <MapPin className="w-7 h-7 text-secondary" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-wide">Highest Paid</p>
                  <p className="text-3xl font-bold mt-2 text-foreground">₹{(Math.max(...salaryInsights.map((s) => s.avgSalary)) / 100000).toFixed(1)}L</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {salaryInsights.find((s) => s.avgSalary === Math.max(...salaryInsights.map((s) => s.avgSalary)))?.location}
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-accent/20 to-accent/5 flex items-center justify-center">
                  <TrendingUp className="w-7 h-7 text-accent" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-wide">Range</p>
                  <p className="text-3xl font-bold mt-2 text-foreground">₹{(Math.min(...salaryInsights.map((s) => s.minSalary)) / 100000).toFixed(0)}L - ₹{(Math.max(...salaryInsights.map((s) => s.maxSalary)) / 100000).toFixed(0)}L</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    entry to senior roles
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
            {/* Location Based Salary */}
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-bold mb-6">Average Salary by City</h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={salaryInsights}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis
                    dataKey="location"
                    angle={-45}
                    textAnchor="end"
                    height={100}
                    stroke="#6b7280"
                  />
                  <YAxis stroke="#6b7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                    formatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                  />
                  <Bar dataKey="avgSalary" fill="#6D28D9" radius={[12, 12, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Experience Based Salary */}
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-bold mb-6">Salary Growth by Experience</h2>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={companySalaryByExperience}>
                  <defs>
                    <linearGradient id="colorSalary" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6D28D9" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#6D28D9" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="experience" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                    formatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgSalary"
                    stroke="#F97316"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorSalary)"
                    dot={{ fill: '#F97316', r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Salary by Skill and Locations Table */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-bold mb-6">Top Paying Skills</h2>
              <div className="space-y-4">
                {salaryBySkill.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-gradient-to-r from-primary/5 to-secondary/5 hover:from-primary/10 hover:to-secondary/10 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-bold text-foreground">{item.skill}</p>
                        <p className="text-xs text-muted-foreground mt-1">Average Annual</p>
                      </div>
                      <p className="text-2xl font-bold text-primary">
                        ₹{(item.avgSalary / 100000).toFixed(1)}L
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-bold mb-6">City-wise Salary Comparison</h2>
              <div className="space-y-4">
                {salaryInsights.map((location, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border-2 border-border/50 hover:border-primary/30 hover:bg-primary/5 transition-all"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <p className="font-bold text-foreground text-lg">
                        {location.location}
                      </p>
                      <p className="text-2xl font-bold text-primary">
                        ₹{(location.avgSalary / 100000).toFixed(1)}L
                      </p>
                    </div>
                    <div className="flex gap-4 text-xs font-semibold text-muted-foreground">
                      <span>Min: ₹{(location.minSalary / 100000).toFixed(1)}L</span>
                      <span>Max: ₹{(location.maxSalary / 100000).toFixed(1)}L</span>
                      <span className="ml-auto text-primary">{location.jobCount.toLocaleString()} jobs</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
