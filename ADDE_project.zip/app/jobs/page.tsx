'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { mockJobs } from '@/lib/mock-data';
import { MapPin, DollarSign, Briefcase, Search, Zap, Star, TrendingUp, Clock } from 'lucide-react';
import { useState } from 'react';

export default function JobsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');

  const filteredJobs = mockJobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation =
      !selectedLocation || job.location.includes(selectedLocation);
    return matchesSearch && matchesLocation;
  });

  const locations = Array.from(
    new Set(mockJobs.map((job) => job.location.split(',')[1]?.trim()))
  );

  return (
    <div className="flex h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8 max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-10">
            <h1 className="text-5xl font-black bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent mb-3">
              Job Opportunities
            </h1>
            <p className="text-lg text-muted-foreground font-medium">
              Explore <span className="text-primary font-bold">{mockJobs.length.toLocaleString()}</span> openings across India's top tech companies
            </p>
          </div>

          {/* Enhanced Filters */}
          <div className="mb-12 space-y-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-xl blur pointer-events-none" />
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground z-10" />
                <Input
                  placeholder="Search jobs or companies..."
                  className="relative pl-14 py-4 rounded-xl border-2 border-border/50 focus:border-primary transition-all text-base font-medium"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="px-6 py-4 rounded-xl border-2 border-border/50 bg-card/50 hover:bg-card focus:border-primary transition-all font-semibold text-foreground min-w-[220px]"
              >
                <option value="">All Locations</option>
                {locations.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <p className="text-sm font-bold text-foreground">
                  <span className="text-primary">{filteredJobs.length}</span> {filteredJobs.length === 1 ? 'opportunity' : 'opportunities'} available
                </p>
              </div>
            </div>
          </div>

          {/* Jobs Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredJobs.map((job, idx) => (
              <Card
                key={job.id}
                className="group p-0 border-0 shadow-sm hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer h-full flex flex-col bg-gradient-to-br from-card to-card/95"
              >
                {/* Top accent bar */}
                <div className="h-1 bg-gradient-to-r from-primary via-secondary to-primary" />

                <div className="p-8 flex flex-col h-full">
                  {/* Header with company and badge */}
                  <div className="mb-6 flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center font-bold text-lg text-primary">
                          {job.company.charAt(0)}
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-bold text-secondary uppercase tracking-widest">{job.company}</p>
                          <p className="text-sm text-muted-foreground font-medium">Tech Company</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-gradient-to-r from-primary/15 to-secondary/15 group-hover:from-primary/25 group-hover:to-secondary/25 transition-all">
                      <Star className="w-4 h-4 text-primary fill-primary" />
                      <span className="text-xs font-bold text-primary">{job.jobType}</span>
                    </div>
                  </div>

                  {/* Job title */}
                  <h3 className="text-2xl font-black text-foreground mb-6 leading-tight group-hover:text-primary transition-colors">
                    {job.title}
                  </h3>

                  {/* Key metrics in grid */}
                  <div className="grid grid-cols-3 gap-4 mb-6 p-5 bg-gradient-to-br from-primary/5 via-secondary/5 to-primary/5 rounded-xl">
                    <div className="text-center">
                      <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center mx-auto mb-2">
                        <MapPin className="w-4 h-4 text-primary" />
                      </div>
                      <p className="text-xs text-muted-foreground font-bold uppercase mb-1">Location</p>
                      <p className="font-bold text-sm text-foreground leading-tight">{job.location.split(',')[0]}</p>
                    </div>
                    <div className="text-center border-l border-r border-border/50">
                      <div className="w-8 h-8 rounded-lg bg-secondary/20 flex items-center justify-center mx-auto mb-2">
                        <DollarSign className="w-4 h-4 text-secondary" />
                      </div>
                      <p className="text-xs text-muted-foreground font-bold uppercase mb-1">Salary</p>
                      <p className="font-bold text-sm text-foreground leading-tight">₹{(job.salary.min / 100000).toFixed(1)}L</p>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center mx-auto mb-2">
                        <Briefcase className="w-4 h-4 text-accent" />
                      </div>
                      <p className="text-xs text-muted-foreground font-bold uppercase mb-1">Experience</p>
                      <p className="font-bold text-sm text-foreground leading-tight">{job.experience}+ yrs</p>
                    </div>
                  </div>

                  {/* Required skills */}
                  <div className="mb-6">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3">Required Skills</p>
                    <div className="flex flex-wrap gap-2">
                      {job.skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-primary/15 to-secondary/15 text-primary text-xs font-bold hover:from-primary/25 hover:to-secondary/25 transition-all inline-flex items-center gap-1"
                        >
                          <Zap className="w-3 h-3" />
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Footer with posted date and expand indicator */}
                  <div className="mt-auto flex items-center justify-between pt-6 border-t border-border/50">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-xs font-medium text-muted-foreground">
                        Posted {new Date(job.posted).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-primary font-bold group-hover:gap-3 transition-all">
                      <span className="text-sm">View Details</span>
                      <TrendingUp className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
