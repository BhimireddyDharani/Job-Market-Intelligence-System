'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  ReferenceLine,
} from 'recharts';
import { forecastData, jobTrendData } from '@/lib/mock-data';
import { TrendingUp, AlertCircle, Zap } from 'lucide-react';

const skillsForecasts = [
  { skill: 'AI/ML Engineers', forecast2024: 8500, forecast2025: 12000, forecast2026: 16500 },
  { skill: 'Cloud Architects', forecast2024: 7200, forecast2025: 9800, forecast2026: 13200 },
  { skill: 'Cybersecurity Experts', forecast2024: 6800, forecast2025: 9200, forecast2026: 12500 },
  { skill: 'DevOps Engineers', forecast2024: 5900, forecast2025: 7600, forecast2026: 9800 },
];

export default function ForecastPage() {
  const latestForecast = forecastData[forecastData.length - 1];
  const maxForecast = Math.max(
    ...forecastData.filter((d) => d.forecast).map((d) => d.forecast || 0)
  );

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Job Market Forecasting
            </h1>
            <p className="text-muted-foreground">
              ML-powered predictions for future job trends and market demand
            </p>
          </div>

          {/* Key Insights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">
                  Predicted Demand (Jan 2025)
                </p>
                <p className="text-2xl font-bold mt-1">
                  {(maxForecast / 1000).toFixed(1)}K
                </p>
                <p className="text-xs text-green-600 mt-2">
                  +18.5% growth expected
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">
                  Fastest Growing Role
                </p>
                <p className="text-2xl font-bold mt-1">AI/ML Engineer</p>
                <p className="text-xs text-green-600 mt-2">
                  +94% growth by 2026
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-accent" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">
                  Confidence Score
                </p>
                <p className="text-2xl font-bold mt-1">87%</p>
                <p className="text-xs text-muted-foreground mt-2">
                  based on historical data
                </p>
              </div>
            </Card>
          </div>

          {/* Main Forecast Chart */}
          <Card className="p-6 mb-8">
            <h2 className="text-lg font-bold mb-4">
              12-Month Job Market Forecast
            </h2>
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={forecastData}>
                <defs>
                  <linearGradient id="colorForecast" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0088FE" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#0088FE" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00C49F" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#00C49F" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="actual"
                  stroke="#00C49F"
                  fillOpacity={1}
                  fill="url(#colorActual)"
                  name="Actual Data"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="forecast"
                  stroke="#0088FE"
                  fillOpacity={1}
                  fill="url(#colorForecast)"
                  name="Forecast"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
                <ReferenceLine
                  x="Sep"
                  stroke="#999"
                  label={{ value: 'Forecast starts', position: 'top' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          {/* Skills Demand Forecast */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">
                Skills Demand Forecast (2024-2026)
              </h2>
              <div className="space-y-4">
                {skillsForecasts.map((skill, idx) => (
                  <div key={idx} className="border-b border-border last:border-0 pb-4 last:pb-0">
                    <p className="font-semibold text-foreground mb-2">{skill.skill}</p>
                    <div className="flex gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">2024</p>
                        <p className="font-bold text-primary">
                          {skill.forecast2024.toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">2025</p>
                        <p className="font-bold text-secondary">
                          {skill.forecast2025.toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">2026</p>
                        <p className="font-bold text-accent">
                          {skill.forecast2026.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 w-full h-1 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-primary via-secondary to-accent"
                        style={{
                          width: `${(skill.forecast2026 / 20000) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Year-over-Year Growth</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={skillsForecasts}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="skill" angle={-15} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="forecast2024" fill="#0088FE" name="2024" />
                  <Bar dataKey="forecast2025" fill="#00C49F" name="2025" />
                  <Bar dataKey="forecast2026" fill="#FFBB28" name="2026" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Forecast Accuracy */}
          <Card className="p-6">
            <h2 className="text-lg font-bold mb-6">Forecast Methodology</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-muted/50">
                <h3 className="font-semibold text-foreground mb-2">
                  Historical Analysis
                </h3>
                <p className="text-sm text-muted-foreground">
                  Machine learning models trained on 5+ years of job market data
                </p>
              </div>
              <div className="p-4 rounded-lg bg-muted/50">
                <h3 className="font-semibold text-foreground mb-2">
                  Market Indicators
                </h3>
                <p className="text-sm text-muted-foreground">
                  Integration with economic indicators and hiring trends
                </p>
              </div>
              <div className="p-4 rounded-lg bg-muted/50">
                <h3 className="font-semibold text-foreground mb-2">
                  Skill Demand Signals
                </h3>
                <p className="text-sm text-muted-foreground">
                  Real-time monitoring of job postings and skill mentions
                </p>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
