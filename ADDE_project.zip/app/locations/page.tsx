'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { locationData } from '@/lib/mock-data';
import { MapPin, TrendingUp, Users } from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

const costOfLiving = [
  { location: 'San Francisco', costIndex: 195 },
  { location: 'New York', costIndex: 185 },
  { location: 'Seattle', costIndex: 165 },
  { location: 'Boston', costIndex: 160 },
  { location: 'Austin', costIndex: 125 },
  { location: 'Denver', costIndex: 130 },
];

export default function LocationsPage() {
  const totalJobs = locationData.reduce((sum, loc) => sum + loc.jobCount, 0);
  const highestPayingLocation = locationData.reduce((max, loc) =>
    loc.salaryAvg > max.salaryAvg ? loc : max
  );

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Location Intelligence
            </h1>
            <p className="text-muted-foreground">
              Job distribution and salary insights across major tech hubs
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <MapPin className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Top Location</p>
                <p className="text-2xl font-bold mt-1">{locationData[0]?.location}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  {locationData[0]?.jobCount.toLocaleString()} job openings
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Highest Paying</p>
                <p className="text-2xl font-bold mt-1">${(highestPayingLocation.salaryAvg / 1000).toFixed(0)}K</p>
                <p className="text-xs text-muted-foreground mt-2">
                  {highestPayingLocation.location}
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Total Jobs</p>
                <p className="text-2xl font-bold mt-1">
                  {totalJobs.toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  across {locationData.length} locations
                </p>
              </div>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Jobs by Location */}
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Job Count by Location</h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={locationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="location" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="jobCount" fill="#0088FE" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Location Distribution */}
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Job Distribution</h2>
              <ResponsiveContainer width="100%" height={350}>
                <PieChart>
                  <Pie
                    data={locationData}
                    dataKey="jobCount"
                    nameKey="location"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label
                  >
                    {locationData.map((_, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Salary vs Jobs Scatter */}
          <Card className="p-6 mb-8">
            <h2 className="text-lg font-bold mb-4">Salary vs Job Count Analysis</h2>
            <ResponsiveContainer width="100%" height={350}>
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis
                  dataKey="jobCount"
                  type="number"
                  name="Job Count"
                  label={{ value: 'Job Count', position: 'insideBottomRight', offset: -5 }}
                />
                <YAxis
                  dataKey="salaryAvg"
                  type="number"
                  name="Avg Salary"
                  label={{ value: 'Avg Salary ($)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                  }}
                  formatter={(value) => [
                    value > 1000 ? `$${(value / 1000).toFixed(0)}K` : value,
                  ]}
                />
                <Scatter
                  name="Locations"
                  data={locationData}
                  fill="#0088FE"
                />
              </ScatterChart>
            </ResponsiveContainer>
          </Card>

          {/* Cost of Living Impact */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-6">Location Details</h2>
              <div className="space-y-3">
                {locationData.map((loc, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg hover:bg-muted/50 transition-colors border border-border"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-foreground">
                        {loc.location}
                      </p>
                      <p className="font-bold text-primary">
                        ${loc.salaryAvg.toLocaleString()}
                      </p>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {loc.jobCount.toLocaleString()} job openings
                    </p>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Cost of Living Index</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={costOfLiving}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="location" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                    formatter={(value) => `${value} (Base: 100)`}
                  />
                  <Bar dataKey="costIndex" fill="#FFBB28" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
