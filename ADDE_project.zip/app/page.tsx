'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
} from 'recharts';
import {
  TrendingUp,
  Users,
  Briefcase,
  DollarSign,
  Zap,
  Target,
} from 'lucide-react';
import {
  keyMetrics,
  jobTrendData,
  skillsDemandData,
  companyHiringData,
} from '@/lib/mock-data';

const COLORS = ['#6D28D9', '#F97316', '#EC4899', '#3B82F6', '#8B5CF6'];
const CHART_COLORS = {
  primary: '#6D28D9',
  secondary: '#F97316', 
  accent: '#EC4899',
  success: '#10B981',
};

function MetricCard({
  icon: Icon,
  label,
  value,
  change,
  gradient,
}: {
  icon: any;
  label: string;
  value: string | number;
  change?: string;
  gradient?: string;
}) {
  return (
    <Card className={`relative p-6 overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 ${gradient || 'bg-white'}`}>
      <div className="absolute inset-0 opacity-5" />
      <div className="relative z-10 flex items-start gap-4">
        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
          <Icon className="w-7 h-7 text-primary" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <p className="text-3xl font-bold mt-2 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            {typeof value === 'number' && value > 1000000
              ? `₹${(value / 1000000).toFixed(1)}M`
              : typeof value === 'number' && value > 1000
              ? `₹${(value / 1000).toFixed(0)}K`
              : value}
          </p>
          {change && (
            <p className="text-xs font-semibold text-green-600 mt-3 flex items-center gap-1">
              <Zap className="w-3 h-3" /> {change}
            </p>
          )}
        </div>
      </div>
    </Card>
  );
}

export default function Dashboard() {
  const topSkills = skillsDemandData.slice(0, 5);
  const topCompanies = companyHiringData.slice(0, 3);

  return (
    <div className="flex h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Hero Header */}
          <div className="mb-10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-5xl font-black bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent mb-2">
                  JobIntel India
                </h1>
                <p className="text-lg text-muted-foreground font-medium">
                  Real-time Job Market Intelligence for India's Tech Ecosystem
                </p>
              </div>
              <div className="hidden lg:flex items-center gap-2 text-sm font-semibold text-primary">
                <Target className="w-5 h-5" />
                Last updated: Today
              </div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <MetricCard
              icon={Briefcase}
              label="Active Positions"
              value={keyMetrics.totalJobs.toLocaleString()}
              change={`+${keyMetrics.jobGrowthYoY}% Growth`}
            />
            <MetricCard
              icon={Users}
              label="Hiring Companies"
              value={keyMetrics.totalCompanies.toLocaleString()}
              change={`${keyMetrics.hiringOutlook}% Positive Outlook`}
            />
            <MetricCard
              icon={DollarSign}
              label="Avg Tech Salary"
              value={keyMetrics.avgTechSalary}
              change="Senior roles up 18%"
            />
            <MetricCard
              icon={Zap}
              label="Top Skill"
              value={keyMetrics.mostDemandedSkill}
              change="9,250 open roles"
            />
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
            {/* Job Trends by Sector */}
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Job Growth by Sector</h2>
                <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse" />
              </div>
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={jobTrendData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="colorTech" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6D28D9" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#6D28D9" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="colorFinance" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#F97316" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#F97316" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="colorAuto" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EC4899" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#EC4899" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="month" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                  />
                  <Legend wrapperStyle={{ paddingTop: '20px' }} />
                  <Line
                    type="monotone"
                    dataKey="tech"
                    stroke="#6D28D9"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorTech)"
                    dot={{ fill: '#6D28D9', r: 5 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="finance"
                    stroke="#F97316"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorFinance)"
                    dot={{ fill: '#F97316', r: 5 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="automotive"
                    stroke="#EC4899"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorAuto)"
                    dot={{ fill: '#EC4899', r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            {/* Top Skills Demand */}
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Skills Demand Ranking</h2>
                <span className="text-xs font-bold text-primary bg-primary/10 px-3 py-1 rounded-full">TRENDING</span>
              </div>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={topSkills} layout="vertical" margin={{ top: 5, right: 30, left: 100, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis type="number" stroke="#6b7280" />
                  <YAxis dataKey="skill" type="category" stroke="#6b7280" width={100} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                  />
                  <Bar dataKey="demand" fill="#6D28D9" radius={[0, 12, 12, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Bottom Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Top Hiring Companies */}
            <Card className="lg:col-span-2 p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-bold mb-6">Top Hiring Companies</h2>
              <div className="space-y-4">
                {topCompanies.map((company, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-gradient-to-r from-primary/5 to-secondary/5 hover:from-primary/10 hover:to-secondary/10 transition-all group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex-1">
                        <p className="font-bold text-lg text-foreground group-hover:text-primary transition-colors">
                          {idx + 1}. {company.company}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {company.activeJobs} active positions • Avg hire time: {company.avgHireTime} days
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex gap-6">
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Growth</p>
                          <p className="text-lg font-bold text-secondary">+{company.growth.toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Recent Hires</p>
                          <p className="text-lg font-bold text-primary">{(company.recentHires / 1000).toFixed(1)}K</p>
                        </div>
                      </div>
                      <div className="w-20 h-20 rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                        <span className="text-2xl font-bold text-primary opacity-50">{idx + 1}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Skills Distribution */}
            <Card className="p-7 border-0 shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-bold mb-6">Skills Demand Share</h2>
              <ResponsiveContainer width="100%" height={320}>
                <PieChart>
                  <Pie
                    data={topSkills}
                    dataKey="demand"
                    nameKey="skill"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                  >
                    {topSkills.map((_, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: 'none',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
