'use client';

import { Sidebar } from '@/components/sidebar';
import { Card } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { companyHiringData } from '@/lib/mock-data';
import { Users, TrendingUp, Clock } from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const hiringTimeline = [
  { month: 'Jan', hires: 150, openings: 180 },
  { month: 'Feb', hires: 180, openings: 200 },
  { month: 'Mar', hires: 160, openings: 190 },
  { month: 'Apr', hires: 200, openings: 220 },
  { month: 'May', hires: 220, openings: 240 },
  { month: 'Jun', hires: 250, openings: 280 },
];

export default function CompaniesPage() {
  const totalActiveJobs = companyHiringData.reduce((sum, c) => sum + c.activeJobs, 0);
  const avgHireTime = (
    companyHiringData.reduce((sum, c) => sum + c.avgHireTime, 0) /
    companyHiringData.length
  ).toFixed(0);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Company Hiring Analytics
            </h1>
            <p className="text-muted-foreground">
              Insights into hiring patterns and company growth trends
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Total Openings</p>
                <p className="text-2xl font-bold mt-1">
                  {totalActiveJobs.toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  across {companyHiringData.length} companies
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Clock className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Avg Hire Time</p>
                <p className="text-2xl font-bold mt-1">{avgHireTime} days</p>
                <p className="text-xs text-muted-foreground mt-2">
                  from application to offer
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Top Grower</p>
                <p className="text-2xl font-bold mt-1">
                  {companyHiringData.reduce((max, c) => (c.growth > max.growth ? c : max)).company}
                </p>
                <p className="text-xs text-green-600 mt-2">
                  +
                  {companyHiringData.reduce((max, c) => (c.growth > max.growth ? c : max)).growth}%
                  YoY
                </p>
              </div>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Active Jobs by Company */}
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Active Openings by Company</h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={companyHiringData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="company" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="activeJobs" fill="#0088FE" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Growth Rate */}
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4">Company Growth Rate</h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={companyHiringData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="company" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                    }}
                    formatter={(value) => `${value}% YoY`}
                  />
                  <Bar dataKey="growth" fill="#00C49F" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Hiring Timeline */}
          <Card className="p-6 mb-8">
            <h2 className="text-lg font-bold mb-4">Industry Hiring Timeline</h2>
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={hiringTimeline}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="hires"
                  stroke="#0088FE"
                  strokeWidth={2}
                  name="Hires"
                />
                <Line
                  type="monotone"
                  dataKey="openings"
                  stroke="#00C49F"
                  strokeWidth={2}
                  name="Openings"
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Companies Table */}
          <Card className="p-6">
            <h2 className="text-lg font-bold mb-6">Company Details</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Company
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Active Jobs
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Recent Hires
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Avg Hire Time
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Growth Rate
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {companyHiringData.map((company, idx) => (
                    <tr
                      key={idx}
                      className="border-b border-border hover:bg-muted/50 transition-colors"
                    >
                      <td className="py-3 px-4 font-semibold text-foreground">
                        {company.company}
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {company.activeJobs} positions
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {company.recentHires}
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {company.avgHireTime} days
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-green-600 font-semibold">
                          +{company.growth}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
