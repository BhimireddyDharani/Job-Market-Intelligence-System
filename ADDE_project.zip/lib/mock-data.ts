// Mock data for Job Market Intelligence Platform - India Focus
export const mockJobs = [
  {
    id: '1',
    title: 'Senior Software Engineer - Python',
    company: 'Tata Consultancy Services (TCS)',
    location: 'Bangalore, Karnataka',
    salary: { min: 1800000, max: 2600000 },
    experience: 5,
    skills: ['Python', 'Django', 'AWS'],
    posted: '2026-04-15',
    jobType: 'Full-time',
  },
  {
    id: '2',
    title: 'Full Stack Engineer - React/Node',
    company: 'Infosys',
    location: 'Pune, Maharashtra',
    salary: { min: 1200000, max: 1800000 },
    experience: 3,
    skills: ['React', 'Node.js', 'MongoDB'],
    posted: '2026-04-14',
    jobType: 'Full-time',
  },
  {
    id: '3',
    title: 'Data Scientist',
    company: 'Wipro',
    location: 'Hyderabad, Telangana',
    salary: { min: 1400000, max: 2100000 },
    experience: 4,
    skills: ['Python', 'Machine Learning', 'SQL'],
    posted: '2026-04-13',
    jobType: 'Full-time',
  },
  {
    id: '4',
    title: 'DevOps Engineer',
    company: 'HCL Technologies',
    location: 'Noida, Uttar Pradesh',
    salary: { min: 1600000, max: 2400000 },
    experience: 4,
    skills: ['Kubernetes', 'Docker', 'Jenkins'],
    posted: '2026-04-12',
    jobType: 'Full-time',
  },
  {
    id: '5',
    title: 'ML Engineer - AI/Deep Learning',
    company: 'Accenture India',
    location: 'Mumbai, Maharashtra',
    salary: { min: 1800000, max: 2800000 },
    experience: 5,
    skills: ['Python', 'TensorFlow', 'Deep Learning'],
    posted: '2026-04-11',
    jobType: 'Full-time',
  },
];

export const skillsDemandData = [
  { skill: 'Python', demand: 9250, growth: 28.5 },
  { skill: 'React', demand: 8120, growth: 24.3 },
  { skill: 'AWS', demand: 7840, growth: 35.8 },
  { skill: 'Java', demand: 7650, growth: 15.2 },
  { skill: 'Kubernetes', demand: 6920, growth: 42.1 },
  { skill: 'Machine Learning', demand: 6450, growth: 51.3 },
  { skill: 'SQL', demand: 7120, growth: 18.5 },
  { skill: 'Docker', demand: 6280, growth: 38.7 },
];

export const salaryInsights = [
  {
    location: 'Bangalore, Karnataka',
    avgSalary: 1850000,
    minSalary: 800000,
    maxSalary: 4500000,
    jobCount: 3250,
  },
  {
    location: 'Mumbai, Maharashtra',
    avgSalary: 1720000,
    minSalary: 750000,
    maxSalary: 4200000,
    jobCount: 2850,
  },
  {
    location: 'Hyderabad, Telangana',
    avgSalary: 1650000,
    minSalary: 700000,
    maxSalary: 3800000,
    jobCount: 2480,
  },
  {
    location: 'Pune, Maharashtra',
    avgSalary: 1580000,
    minSalary: 680000,
    maxSalary: 3600000,
    jobCount: 2120,
  },
  {
    location: 'Noida, Uttar Pradesh',
    avgSalary: 1450000,
    minSalary: 620000,
    maxSalary: 3400000,
    jobCount: 1850,
  },
];

export const companySalaryByExperience = [
  { experience: '0-2 years', avgSalary: 650000 },
  { experience: '2-5 years', avgSalary: 1150000 },
  { experience: '5-10 years', avgSalary: 1850000 },
  { experience: '10+ years', avgSalary: 2850000 },
];

export const companyHiringData = [
  {
    company: 'TCS',
    activeJobs: 285,
    avgHireTime: 32,
    growth: 18.5,
    recentHires: 2450,
  },
  {
    company: 'Infosys',
    activeJobs: 248,
    avgHireTime: 28,
    growth: 22.3,
    recentHires: 1890,
  },
  {
    company: 'Wipro',
    activeJobs: 215,
    avgHireTime: 26,
    growth: 15.8,
    recentHires: 1620,
  },
  {
    company: 'HCL Technologies',
    activeJobs: 192,
    avgHireTime: 24,
    growth: 28.4,
    recentHires: 1280,
  },
  {
    company: 'Accenture India',
    activeJobs: 168,
    avgHireTime: 22,
    growth: 35.2,
    recentHires: 980,
  },
];

export const jobTrendData = [
  { month: 'Jan', tech: 4200, finance: 2100, automotive: 2800 },
  { month: 'Feb', tech: 4850, finance: 2450, automotive: 3200 },
  { month: 'Mar', tech: 5100, finance: 2600, automotive: 3400 },
  { month: 'Apr', tech: 5800, finance: 3100, automotive: 3900 },
  { month: 'May', tech: 6400, finance: 3400, automotive: 4200 },
  { month: 'Jun', tech: 7200, finance: 3800, automotive: 4800 },
];

export const locationData = [
  { location: 'Bangalore', jobCount: 3250, salaryAvg: 1850000 },
  { location: 'Mumbai', jobCount: 2850, salaryAvg: 1720000 },
  { location: 'Hyderabad', jobCount: 2480, salaryAvg: 1650000 },
  { location: 'Pune', jobCount: 2120, salaryAvg: 1580000 },
  { location: 'Noida', jobCount: 1850, salaryAvg: 1450000 },
  { location: 'Chennai', jobCount: 1620, salaryAvg: 1380000 },
];

export const forecastData = [
  { month: 'Jul', actual: 7800, forecast: 7800 },
  { month: 'Aug', actual: 8400, forecast: 8250 },
  { month: 'Sep', actual: 9200, forecast: 9100 },
  { month: 'Oct', forecast: 9800 },
  { month: 'Nov', forecast: 10400 },
  { month: 'Dec', forecast: 11200 },
  { month: 'Jan', forecast: 12100 },
];

export const keyMetrics = {
  totalJobs: 24580,
  totalCompanies: 1850,
  avgSalary: 1680000,
  avgTechSalary: 1920000,
  mostDemandedSkill: 'Python',
  topLocation: 'Bangalore, Karnataka',
  jobGrowthYoY: 34.2,
  avgHireTime: 27,
  hiringOutlook: 68,
  skillGapPercentage: 44,
};
