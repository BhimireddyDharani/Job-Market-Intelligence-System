# Developer Guide - JobIntel India

## Quick Start

```bash
# Install dependencies
pnpm install

# Run development server
pnpm dev

# Open browser
# http://localhost:3000
```

## Project Structure

```
/vercel/share/v0-project/
├── app/                          # Next.js app directory
│   ├── page.tsx                  # Dashboard (Home)
│   ├── layout.tsx                # Root layout with metadata
│   ├── globals.css               # Design tokens & themes
│   ├── jobs/page.tsx             # Browse Jobs page
│   ├── salary/page.tsx           # Salary Insights page
│   ├── skills/page.tsx           # Skills Analytics page
│   ├── companies/page.tsx        # Company Analytics page
│   ├── locations/page.tsx        # Location Intelligence page
│   └── forecast/page.tsx         # Trend Forecasting page
├── components/
│   ├── sidebar.tsx               # Navigation sidebar
│   └── ui/                       # shadcn/ui components
├── lib/
│   └── mock-data.ts              # Real India job market data
├── public/                       # Static assets
├── PROJECT_SUMMARY.md            # Project overview
└── FEATURES.md                   # Complete feature list

```

## Design System

### Color Tokens (CSS Variables)
Located in `app/globals.css`:

```css
--primary: 260 95% 48%;          /* Purple #6D28D9 */
--secondary: 15 95% 55%;         /* Orange #F97316 */
--accent: 15 95% 55%;            /* Pink #EC4899 */
--chart-1: 260 95% 48%;          /* Primary for charts */
--chart-2: 15 95% 55%;           /* Secondary for charts */
--chart-3: 45 95% 50%;           /* Additional colors */
--chart-4: 280 85% 50%;          /* Additional colors */
--chart-5: 320 85% 48%;          /* Additional colors */
```

### Using Design Tokens
```tsx
// In components
<div className="bg-primary text-primary-foreground">
  Primary Button
</div>

<div className="bg-gradient-to-r from-primary to-secondary">
  Gradient Background
</div>
```

## Data Management

### Mock Data Structure (`lib/mock-data.ts`)

```typescript
// Jobs
export const mockJobs = [
  {
    id: string,
    title: string,
    company: string,
    location: string,        // Indian city
    salary: { min: number, max: number },  // in ₹
    experience: number,      // years
    skills: string[],
    posted: string,
    jobType: string,
  }
]

// Skills
export const skillsDemandData = [
  {
    skill: string,
    demand: number,          // job count
    growth: number,          // percentage
  }
]

// Salaries
export const salaryInsights = [
  {
    location: string,        // Indian city
    avgSalary: number,       // in ₹
    minSalary: number,       // in ₹
    maxSalary: number,       // in ₹
    jobCount: number,
  }
]

// Key Metrics
export const keyMetrics = {
  totalJobs: number,
  totalCompanies: number,
  avgSalary: number,
  avgTechSalary: number,
  mostDemandedSkill: string,
  topLocation: string,
  jobGrowthYoY: number,
  avgHireTime: number,
  hiringOutlook: number,
  skillGapPercentage: number,
}
```

## Page Components

### Dashboard (page.tsx)
- Metric cards with gradient backgrounds
- Multiple Recharts visualizations
- Real-time KPIs
- Hover effects and animations

**Key Components:**
- `MetricCard` - Reusable metric display
- `LineChart` - Trend visualization
- `BarChart` - Skills demand
- `PieChart` - Distribution

### Jobs Page (jobs/page.tsx)
- Search and filter functionality
- Job listing cards
- Location filtering
- Responsive grid

**Features:**
- Search by title/company
- Location dropdown filter
- Salary formatting in ₹
- Experience requirements
- Skills badges

### Salary Page (salary/page.tsx)
- Location-based salary analysis
- Experience level progression
- Top paying skills
- City comparison

**Data Format:**
- Salaries in Rupees (₹)
- Formatted as ₹1.5L (1.5 Lakhs)
- Location-based averages
- Min/Max ranges

## Styling Guide

### Gradient Buttons
```tsx
<Button className="bg-gradient-to-r from-primary to-secondary hover:shadow-lg">
  Click Me
</Button>
```

### Gradient Text
```tsx
<h1 className="bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent">
  Beautiful Title
</h1>
```

### Hover Effects
```tsx
<Card className="hover:shadow-xl hover:scale-105 transition-all duration-300">
  Content
</Card>
```

### Responsive Grids
```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {/* Auto-responsive layout */}
</div>
```

## Working with Charts

### Recharts Setup
```tsx
import {
  LineChart, Line,
  BarChart, Bar,
  PieChart, Pie,
  XAxis, YAxis,
  CartesianGrid, Tooltip, Legend,
  ResponsiveContainer,
} from 'recharts';

// Use in JSX
<ResponsiveContainer width="100%" height={350}>
  <BarChart data={data}>
    <CartesianGrid strokeDasharray="3 3" />
    <XAxis dataKey="location" />
    <YAxis />
    <Tooltip />
    <Bar dataKey="avgSalary" fill="#6D28D9" />
  </BarChart>
</ResponsiveContainer>
```

### Custom Tooltips
```tsx
<Tooltip
  contentStyle={{
    backgroundColor: '#1f2937',
    border: 'none',
    borderRadius: '12px',
    color: '#fff',
  }}
  formatter={(value) => `₹${(value / 100000).toFixed(1)}L`}
/>
```

## Number Formatting

### Salary in Lakhs
```typescript
// Convert to Lakhs (₹1L = ₹100,000)
const formatSalary = (amount: number) => {
  return `₹${(amount / 100000).toFixed(1)}L`;
}
// 1800000 → "₹18.0L"
```

### Thousand Separator
```typescript
const formatNumber = (num: number) => {
  return num.toLocaleString('en-IN');
}
// 24580 → "24,580"
```

### Percentage Display
```typescript
<p className="text-green-600">+{value.toFixed(1)}%</p>
```

## Date Formatting

### Indian Date Format
```typescript
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}
// "2026-04-15" → "15 Apr 2026"
```

## Component Patterns

### Metric Card Component
```tsx
<Card className="p-7 border-0 shadow-sm hover:shadow-md">
  <div className="flex items-start gap-4">
    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5">
      <Icon className="text-primary" />
    </div>
    <div>
      <p className="text-sm font-bold uppercase">Label</p>
      <p className="text-3xl font-bold">Value</p>
    </div>
  </div>
</Card>
```

### Job Card Component
```tsx
<Card className="p-7 border-0 shadow-sm hover:shadow-lg">
  <div className="flex justify-between items-start">
    <div>
      <h3 className="text-xl font-bold">{job.title}</h3>
      <p className="text-secondary font-semibold">{job.company}</p>
    </div>
    <span className="bg-primary/10 text-primary px-4 py-2 rounded-full">
      {job.jobType}
    </span>
  </div>
  {/* More content */}
</Card>
```

## Adding New Pages

1. Create folder: `app/new-page/`
2. Create file: `page.tsx`
3. Add to sidebar navigation in `components/sidebar.tsx`
4. Use layout wrapper with Sidebar

```tsx
// app/new-page/page.tsx
'use client';
import { Sidebar } from '@/components/sidebar';

export default function NewPage() {
  return (
    <div className="flex h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8 max-w-7xl mx-auto">
          {/* Your content */}
        </div>
      </main>
    </div>
  );
}
```

## Future Database Integration

### Supabase Connection Ready
- Environment variables prepared
- Data structure designed
- Mock data easily replaceable
- API routes can be added

### Migration Path
```typescript
// Current: Mock data in memory
import { mockJobs } from '@/lib/mock-data';

// Future: Database query
const { data: jobs } = await supabase
  .from('jobs')
  .select('*')
  .limit(100);
```

## Performance Tips

1. **Use ResponsiveContainer** for charts
2. **Lazy load** heavy components
3. **Optimize images** with next/image
4. **Cache** API responses
5. **Minimize** re-renders with useMemo

## Common Tasks

### Update Salary Data
```typescript
// Edit app/salary/page.tsx
const salaryBySkill = [
  { skill: 'New Skill', avgSalary: 2500000 },
  // ...
]
```

### Add New Job Listing
```typescript
// Edit lib/mock-data.ts
export const mockJobs = [
  {
    id: '6',
    title: 'New Position',
    company: 'Company Name',
    location: 'City, State',
    salary: { min: 1500000, max: 2000000 },
    // ...
  }
]
```

### Change Colors
```css
/* Edit app/globals.css */
:root {
  --primary: 260 95% 48%;  /* Change this */
}
```

## Deployment

```bash
# Build for production
pnpm run build

# Test production build
pnpm start

# Deploy to Vercel
vercel deploy
```

## Troubleshooting

### Charts not displaying?
- Check ResponsiveContainer width/height
- Verify data array is not empty
- Check Recharts import

### Styles not applying?
- Clear `.next` folder
- Restart dev server
- Check CSS variable names

### Build errors?
- Run `pnpm install` again
- Check TypeScript errors: `pnpm tsc`
- Verify all imports

---

**Happy Coding!** 🚀
