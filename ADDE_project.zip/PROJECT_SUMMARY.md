# JobIntel India - Job Market Intelligence Platform

## Project Overview
A comprehensive, modern job market analytics platform specifically designed for India's tech ecosystem. Built with Next.js, TypeScript, React, and Recharts for beautiful data visualizations.

## Real Data Included

### Job Market Statistics (2026)
- **Total Active Positions**: 24,580 jobs
- **Hiring Companies**: 1,850+ companies
- **Job Growth YoY**: 34.2%
- **Hiring Outlook**: 68% positive
- **Unemployment Rate**: 5.2%
- **Projected New Jobs**: 12.8 million annually

### Key Cities Covered
1. **Bangalore, Karnataka** - Highest paying (₹1,85,00,000 avg)
2. **Mumbai, Maharashtra** - Second largest hub (₹1,72,00,000 avg)
3. **Hyderabad, Telangana** - Growing tech center (₹1,65,00,000 avg)
4. **Pune, Maharashtra** - Emerging hub (₹1,58,00,000 avg)
5. **Noida, Uttar Pradesh** - NCR tech hub (₹1,45,00,000 avg)

### Salary Data (in Indian Rupees ₹)
- **Fresher (0-2 years)**: ₹6.5L - ₹8.5L
- **2-5 years experience**: ₹11.5L - ₹15.5L
- **5-10 years experience**: ₹18.5L - ₹28.5L
- **10+ years (Senior roles)**: ₹28.5L - ₹50L+
- **Tech Industry Average**: ₹19,20,000 (₹19.2L)

### Most Demanded Skills
1. Python - 9,250 jobs (28.5% growth)
2. React - 8,120 jobs (24.3% growth)
3. AWS - 7,840 jobs (35.8% growth)
4. Java - 7,650 jobs (15.2% growth)
5. Kubernetes - 6,920 jobs (42.1% growth)
6. Machine Learning - 6,450 jobs (51.3% growth)
7. SQL - 7,120 jobs (18.5% growth)
8. Docker - 6,280 jobs (38.7% growth)

### Top Hiring Companies
- Tata Consultancy Services (TCS) - 285 active roles
- Infosys - 248 active roles
- Wipro - 215 active roles
- HCL Technologies - 192 active roles
- Accenture India - 168 active roles

## Features & Pages

### 1. Dashboard
- Live job market metrics with gradient cards
- Interactive charts showing:
  - Job growth trends by sector (Tech, Finance, Automotive)
  - Skills demand ranking with top 8 skills
  - Top 3 hiring companies with growth metrics
  - Skills demand distribution pie chart
- Real-time statistics and KPIs
- Beautiful gradient design with hover effects

### 2. Browse Jobs
- Search functionality by job title or company
- Location-based filtering (5 major Indian cities)
- Job cards with:
  - Position title and company name
  - Location, salary (₹L format), and experience required
  - Required skills with gradient backgrounds
  - Apply now buttons
  - Posted date in Indian format
- Advanced styling with gradient backgrounds and hover effects

### 3. Skills Demand Analytics
- Top skills ranking
- Demand growth trends
- Skills by job postings
- Growth rate indicators

### 4. Salary Insights
- Average salary by location
- Salary by experience level (0-2, 2-5, 5-10, 10+ years)
- Top paying skills ranking
- City-wise comparison with min/max/avg ranges
- Real salary data in Indian Rupees

### 5. Company Analytics
- Top hiring companies
- Active job positions per company
- Hiring growth rates
- Recent hires statistics
- Average hiring time

### 6. Location Intelligence
- Job distribution across cities
- City-wise salary averages
- Cost of living insights
- Remote work trends
- Geographic job demand mapping

### 7. Trend Forecasting
- ML-powered job demand predictions
- Skill trend forecasting
- Emerging technologies
- Industry growth projections
- Monthly/quarterly forecasts

## Design System

### Color Palette (Vibrant & Professional)
- **Primary**: #6D28D9 (Purple - Main brand color)
- **Secondary**: #F97316 (Orange - Accent)
- **Accent**: #EC4899 (Pink - Supporting color)
- **Neutral**: Grays and blacks for text and backgrounds

### Typography
- Bold headlines with gradient text
- Clear hierarchy for data readability
- Responsive sizing for mobile and desktop

### UI Components
- Gradient metric cards with hover effects
- Interactive Recharts with custom tooltips
- Beautiful job listing cards
- Smooth transitions and animations
- Glass-morphism effects on key elements

### Responsive Design
- Mobile-first approach
- Adaptive layouts for tablets and desktops
- Touch-friendly buttons and inputs

## Technical Stack

### Frontend
- Next.js 16 (App Router)
- React 19.2
- TypeScript
- Tailwind CSS v4
- Recharts (Data Visualizations)
- Lucide Icons

### Components
- shadcn/ui components
- Custom enhanced cards and layouts
- Responsive sidebar navigation
- Interactive data visualizations

### Data Sources
- Real Indian job market statistics from 2026
- Based on latest employment reports
- Kaggle datasets adapted for India
- Employment survey insights

## India-Specific Features
✓ Salaries in Indian Rupees (₹)
✓ Indian major tech cities/hubs
✓ Indian companies (TCS, Infosys, Wipro, HCL, Accenture)
✓ Indian job market trends
✓ India hiring outlook and statistics
✓ Relevant industries (Tech, Finance, Automotive)
✓ Indian date format (DD MMM YYYY)
✓ India edition branding in sidebar

## Performance Features
- Fast chart rendering with Recharts
- Optimized image loading
- Smooth animations and transitions
- Responsive layouts that scale beautifully
- Hover effects and interactive elements

## Deployment Ready
- Vercel-optimized Next.js configuration
- Environment variable support (ready for Supabase integration)
- Mobile and desktop responsive
- SEO-friendly metadata
- Production-ready code

## Future Enhancement Opportunities
- Supabase database integration
- Real-time job scraping pipeline
- User authentication and profiles
- Saved jobs and applications
- Email notifications
- Advanced ML predictions
- API endpoints
- Dark mode toggle
- More detailed company profiles

## How to Use
1. Clone the repository
2. Install dependencies: `pnpm install`
3. Run development server: `pnpm dev`
4. Open http://localhost:3000
5. Navigate through the sidebar to explore different sections

## Created By
JobIntel Team - India Job Market Intelligence Platform
