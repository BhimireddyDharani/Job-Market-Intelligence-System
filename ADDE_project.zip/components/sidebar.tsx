'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  BarChart3,
  Briefcase,
  TrendingUp,
  Users,
  MapPin,
  Brain,
  Home,
} from 'lucide-react';

const navItems = [
  { href: '/', icon: Home, label: 'Dashboard', end: true },
  { href: '/jobs', icon: Briefcase, label: 'Browse Jobs' },
  { href: '/skills', icon: Brain, label: 'Skills Demand' },
  { href: '/salary', icon: BarChart3, label: 'Salary Insights' },
  { href: '/companies', icon: Users, label: 'Company Analytics' },
  { href: '/locations', icon: MapPin, label: 'Locations' },
  { href: '/forecast', icon: TrendingUp, label: 'Forecast' },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 bg-gradient-to-b from-sidebar to-sidebar/95 border-r border-sidebar-border min-h-screen flex flex-col shadow-lg">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="mb-2">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-primary-foreground font-bold text-lg shadow-lg">
              🇮🇳
            </div>
            <div>
              <h1 className="text-xl font-black bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                JobIntel
              </h1>
              <p className="text-xs font-semibold text-secondary">India Jobs</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-8 space-y-2">
        {navItems.map((item) => {
          const isActive =
            item.end ? pathname === item.href : pathname.startsWith(item.href);
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 relative group ${
                isActive
                  ? 'bg-gradient-to-r from-primary/20 to-secondary/20 text-primary font-semibold shadow-md'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent/30 hover:text-primary'
              }`}
            >
              {isActive && (
                <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-primary/10 to-secondary/10" />
              )}
              <Icon className={`w-5 h-5 relative z-10 ${isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-primary'}`} />
              <span className="font-medium relative z-10">{item.label}</span>
              {isActive && (
                <div className="ml-auto w-2 h-2 rounded-full bg-primary" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Stats Footer */}
      <div className="p-6 border-t border-sidebar-border">
        <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl p-4 mb-4">
          <p className="text-xs font-bold text-primary uppercase tracking-wider mb-2">Live</p>
          <p className="text-2xl font-black text-foreground">24.5K</p>
          <p className="text-xs text-muted-foreground">Jobs Updated Today</p>
        </div>
        <p className="text-xs text-sidebar-foreground/60 text-center">
          JobIntel © 2026 | India Edition
        </p>
      </div>
    </aside>
  );
}
